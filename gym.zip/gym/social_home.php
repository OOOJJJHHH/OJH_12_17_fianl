<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <title>마음가GYM</title>

    <style>
        html, body {
            height: 100%; /* 페이지 전체 높이를 100%로 설정 */
            margin: 0;
        }

        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column; /* flexbox로 콘텐츠와 푸터 정렬 */
        }


        .content {
            margin-top: 100px;
            margin-left: 200px;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-grow: 1; /* 남은 공간을 차지하게 설정 */
        }

        .board-container {
            width: 55%; /* 양옆 너비를 55%로 증가 */
            margin: 20px 0; /* 위아래 여백을 20px로 줄임 */
        }

        .board-container + .board-container {
            margin-left: 40px; /* 게시판 1과 게시판 2 사이에 40px의 여백 추가 */
            margin-right: 40px;
        }

        .board-title {
            margin-bottom: 20px;
            font-size: 1.5em;
            color: #333;
            text-align: center;
        }

        .board-table {
            width: 100%;
            border-collapse: collapse;
        }

        .board-table th,
        .board-table td {
            border: 1px solid #ddd;
            padding: 12px 15px; /* Padding 크기 조정 */
            text-align: center;
            font-size: 1.1em; /* 글자 크기 증가 */
        }

        .board-table th {
            background-color: thistle;
            color: white;
            font-weight: bold;
        }

        .board-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .board-table tr:hover {
            background-color: #f1f1f1;
        }

        .footer {
            background-color: black;
            height: 100px;
            width: 100%;
            font-size: 16px;
            color: white;
            padding: 0 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative; /* 고정되지 않게 설정 */
            bottom: 0;
            left: 0;
            z-index: 100;
        }
  
    </style>
</head>
<body>
    
    <?php require_once("inc/header.php"); ?>
    <?php require_once("social_menu.php"); ?>
    

    <div class="content">
        <!-- 첫 번째 테이블 -->
        <div class="board-container">
            <div class="board-title">게시판 1</div>
            <table class="board-table">
                <thead>
                    <tr>
                        <th>번호</th>
                        <th>제목</th>
                        <th>작성자</th>
                        <th>작성일</th>
                        <th>조회수</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>5</td>
                        <td><a href="post_view.php?id=2">게시판 5의 제목 5</a></td>
                        <td>사용자1</td>
                        <td>2024-11-20</td>
                        <td>45</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td><a href="post_view.php?id=2">게시판 4의 제목 4</a></td>
                        <td>사용자1</td>
                        <td>2024-11-20</td>
                        <td>45</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td><a href="post_view.php?id=2">게시판 3의 제목 3</a></td>
                        <td>사용자1</td>
                        <td>2024-11-20</td>
                        <td>45</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td><a href="post_view.php?id=1">게시판 2의 제목 2</a></td>
                        <td>관리자</td>
                        <td>2024-11-21</td>
                        <td>123</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td><a href="post_view.php?id=2">게시판 1의 제목 1</a></td>
                        <td>사용자1</td>
                        <td>2024-11-20</td>
                        <td>45</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- 두 번째 테이블 -->
        <div class="board-container">
            <div class="board-title">게시판 2</div>
            <table class="board-table">
                <thead>
                    <tr>
                        <th>번호</th>
                        <th>제목</th>
                        <th>작성자</th>
                        <th>작성일</th>
                        <th>조회수</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>5</td>
                        <td><a href="post_view.php?id=2">게시판 5의 제목 5</a></td>
                        <td>사용자1</td>
                        <td>2024-11-20</td>
                        <td>45</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td><a href="post_view.php?id=2">게시판 4의 제목 4</a></td>
                        <td>사용자1</td>
                        <td>2024-11-20</td>
                        <td>45</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td><a href="post_view.php?id=2">게시판 3의 제목 3</a></td>
                        <td>사용자1</td>
                        <td>2024-11-20</td>
                        <td>45</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td><a href="post_view.php?id=1">게시판 2의 제목 2</a></td>
                        <td>관리자</td>
                        <td>2024-11-21</td>
                        <td>123</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td><a href="post_view.php?id=2">게시판 1의 제목 1</a></td>
                        <td>사용자1</td>
                        <td>2024-11-20</td>
                        <td>45</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>  

    <?php require_once("inc/footer.php"); ?>
</body>
</html>
