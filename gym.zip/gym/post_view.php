<?php
session_start(); // Start session
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Q&A 게시물</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
        }
        .image-container {
            background-color: #000;
            height: 300px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .image-container img {
            width: 100%;
            height: auto;
            object-fit: cover;
        }
        .content {
            padding: 15px;
        }
        .post-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
        .post-description {
            font-size: 14px;
            color: #555;
            margin-bottom: 15px;
        }
        .actions {
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 14px;
            border-top: 1px solid #ddd;
            padding: 10px 15px;
        }
        .like-button {
            display: flex;
            align-items: center;
            cursor: pointer;
        }
        .like-button .heart {
            font-size: 20px;
            color: #e74c3c;
            margin-right: 5px;
        }
        .comments {
            padding: 10px 15px;
            border-top: 1px solid #ddd;
        }
        .comment {
            font-size: 14px;
            color: #333;
            margin-bottom: 10px;
        }
        .comment strong {
            font-weight: bold;
            margin-right: 5px;
        }
        .popup {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80%;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            padding: 20px;
            display: none;
            z-index: 1000;
        }
        .popup h3 {
            margin-top: 0;
            font-size: 18px;
        }
        .popup p {
            font-size: 14px;
            color: #555;
        }
        .popup .close {
            display: block;
            margin-top: 20px;
            padding: 10px;
            text-align: center;
            background: #007bff;
            color: #fff;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="container" id="card-1">
    <div class="image-container">
        <img src="img/oh.png" alt="Post Image">
    </div>
    <div class="content">
        <div class="post-title">Q&A 오운완 좋아요</div>
        <div class="post-description">글 제목: 그 쪽이 내 고백 안받아줬으니까 사과해야 하는 거 아니오? 사과해요 나한테!!!</div>
    </div>
    <div class="actions">
        <div class="like-button" onclick="showPopup('card-1')">
            <span class="heart">❤️</span> <span>2000.1만</span>
        </div>
        <div>2.3천 댓글</div>
    </div>
    <div class="comments">
        <div class="comment">
            <strong>사용자1:</strong> 정말 공감됩니다!
        </div>
        <div class="comment">
            <strong>사용자2:</strong> 멋진 생각이네요.
        </div>
    </div>
</div>

<div class="popup" id="popup-card-1">
    <h3>상세 내용</h3>
    <p>여기에 카드 1의 상세 정보를 입력하세요.</p>
    <span class="close" onclick="closePopup('card-1')">닫기</span>
</div>

<script>
    function showPopup(cardId) {
        document.getElementById(`popup-${cardId}`).style.display = 'block';
    }

    function closePopup(cardId) {
        document.getElementById(`popup-${cardId}`).style.display = 'none';
    }
</script>

</body>
</html>