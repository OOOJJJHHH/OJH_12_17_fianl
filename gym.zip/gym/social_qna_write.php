<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>게시글 작성하기</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .form-container {
            width: 60%;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #f9f9f9;
        }

        .form-header {
            text-align: center;
            font-size: 25px;
            font-weight: bold;
            background-color: #3C3C3C;
            color: white;
            padding: 15px 0;
            margin-bottom: 30px;
        }

        table.table2 {
            width: 100%;
            border-collapse: separate;
            border-spacing: 1px;
            margin-bottom: 20px;
        }

        table.table2 td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
            vertical-align: top;
        }

        table.table2 td:first-child {
            width: 100px;
            font-weight: bold;
        }

        

        input[type="text"], textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 5px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
        }

        input[type="submit"] {
            width: 120px;
            height: 40px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <?php require_once("inc/header.php"); ?>
    <?php require_once("social_menu.php"); ?>
    
    <div class="form-container">
        <div class="form-header">게시글 작성하기</div>

        <form method="post" action="write_action.php">
            <table class="table2">
                <tr>
                
                    <td>작성자</td>
                    <td><input type="text" name="name" required></td>
                    <td colspan="2" style="white-space: nowrap; ">
                        작성 일시
                        <div style="display: inline-block; border: 1px solid #000; padding: 0 5px; height: 30px; line-height: 30px; background-color: white; margin-top: 5px;">
                            <?php echo date("Y-m-d H:i"); ?>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>제목</td>
                    <td colspan="2"><input type="text" name="title" required></td>
                </tr>
                <tr>
                    <td>내용</td>
                    <td colspan="2"><textarea name="content" cols="75" rows="15" required></textarea></td>
                </tr>
            </table>

            <div style="text-align: center;">
                <input type="submit" value="작성">
            </div>
        </form>
    </div>
    <?php require_once("inc/footer.php"); ?>
</body>
</html>
        