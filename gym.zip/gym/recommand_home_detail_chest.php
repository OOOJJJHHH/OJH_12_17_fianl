<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <title>마음가GYM</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .sidebar {
            position: fixed;
            left: 15%;
            top: 30%;
            transform: translateY(-50%); /* 수직 중앙 정렬 */
            width: 150px; /* 사이드바 너비 */
            background-color: thistle;
            padding: 20px 10px;
            color: white;
            display: flex;
            flex-direction: column; /* 세로 정렬 */
            align-items: flex-start; /* 왼쪽 정렬 */
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-direction: column; /* 리스트 항목을 세로로 정렬 */
            gap: 10px; /* 항목 간격 */
        }
        .sidebar li {
            margin: 10px;
            font-size: 1.2em;
        }

        .sidebar a:hover {
            color: #ddd; /* 호버 시 색상 변경 */
            cursor: pointer;
        }

        .content-name {
            margin-top: 50px;
            padding: 30px;
            display: fixed;
        }

        .content-name ul {
            font-size: 50px;
            float: left ;
        }

        .image-item {
            margin-top: 50px;
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 40%;
            height: auto;
            margin: 50px;
            margin-bottom: -280px;
        }

        .image-text {
            margin-bottom: 5px; /* 이미지와 텍스트 사이 간격 */
            color: #333;
            font-size: 1.2em;
            font-weight: bold;
            text-align: center;
        }

        .image-item img, .image-item a img {
            width: 300px; /* 원하는 고정 너비 */
            height: 300px; /* 원하는 고정 높이 */
            display: block;
        }

        .left-box{
            font-size: 35px;
            margin-top: 50px;
            border-bottom: 2px solid black;
        }

        ul {
            padding: 0;
            display: flex;
            gap: 10px;
        }
    </style>


</head>
<body>
    
    <?php require_once("inc/header.php"); ?>

    <div class="sidebar">
        <ul>
            <li><a href="recommend_home.php" style="display: inline-block; border-bottom: 4px solid Red; padding-bottom: 5px;">추천 루틴</a></li>
            <li><a href="likeRoutine_home.php" class="nav" >좋아요 루틴</a></li>
            <li><a href="myRoutine_record.php">내 루틴</a></li>
        </ul>
    </div>
    
    <div class="content-name">
        <ul>
            가슴 운동
        </ul>
    </div>



    <ul style="margin-bottom: 300px;">
        <li class="image-item">
            <span class="image-text">밴치프레스</span>
            <a href="recommand_chest_1.php">
            <img src="img/routine/bench.jpg" alt="">
            </a>
        </li>
        <li class="image-item">
            <span class="image-text">딥스</span>
            <a href="recommand_chest_2.php">
            <img src="img/routine/dips.jpg" alt="">
            </a>
        </li>
        <li class="image-item">
            <span class="image-text">케이블 크로스오버 플라이</span>
            <a href="recommand_chest_3.php">
            <img src="img/routine/cable_cross.jpg" alt="">
            </a>
        </li>
        

        
    </ul>

    <ul>
        <li class="image-item">
            <span class="image-text">로우 풀리 케이블 크로스 오버</span>
            <a href="recommand_chest_4.php">
            <img src="img/routine/chest.jpg" alt="">
            </a>
        </li>
        <li class="image-item">
            <span class="image-text">푸시업</span>
            <a href="recommand_chest_5.php">
            <img src="img/routine/pushup.jpg" alt="">
            </a>
        </li>
        
        <li class="image-item">
            <span class="image-text">루틴</span>
            <a href="recommand_routine_none.php">
            <img src="img/index/cantfind.png" alt="">
            </a>
        </li>
        

        
    </ul>


    <?php require_once("inc/footer.php"); ?>
</body>
</html>