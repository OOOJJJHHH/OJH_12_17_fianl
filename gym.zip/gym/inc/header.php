<?php require_once("session.php"); ?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header</title>
    <style>
    /* General Styles */
    body {
        margin: 0;
        font-family: Arial, sans-serif;
    }

    /* Utility Navigation (회원가입, 로그인 등) */
    .util_nav {
        display: flex;
        justify-content: flex-end;
        padding: 5px 15px;
        background-color: #f4f4f4;
        list-style: none;
    }

    .util_nav li {
        margin-left: 15px;
    }

    .util_nav a {
        text-decoration: none;
        color: #333;
        font-size: 0.9em;
    }

    .util_nav a:hover {
        color: #57A0EE;
    }

    /* Main Navigation Styles */
    #header_wrapper {
        width: 100%;
        background-color: #fff;
        padding: 5px 15px;
    }

    header {
        display: flex;
        flex-direction: column; /* Stack items vertically */
        align-items: center;
        padding: 10px 0;
    }

    /* Logo Section */
    .logo_link {
        display: flex;
        align-items: center;
        text-decoration: none;
        margin-bottom: 20px; /* Spacing between logo and nav items */
    }

    .logo_section {
        display: flex;
        align-items: center;
    }

    .logo_icon {
        width: 50px; /* Increased size for logo image */
        height: auto;
        margin-right: 12px; /* Increased space between logo and text */
    }

    .logo_text {
        font-size: 2em; /* Increased font size for logo text */
        font-weight: bold;
        color: #57A0EE;
    }

    /* Navigation Links */
    .nav_container {
        display: flex;
        align-items: center;
        justify-content: center; /* Center all items */
        gap: 30px; /* Add spacing between items */
        width: 100%;
    }

    .nav_item {
        display: flex;
        flex-direction: column; /* Changed to column to stack image and text */
        align-items: center;
        margin-bottom: 20px; /* Add space between nav items */
        text-decoration: none;
        color: #333;
        font-size: 0.9em;
    }

    .nav_icon {
        width: 50px; /* Increased size for nav images */
        height: 50px;
        margin-bottom: 10px; /* Added space between image and text */
    }

    .nav_title {
        font-size: 1.1em; /* Adjusted font size for text */
        font-weight: normal;
        text-align: center; /* Centered text */
    }

    .nav_item:hover {
        color: #57A0EE;
    }

    .nav_item:hover span {
        text-decoration: underline;
    }

    /* Search input styles */
    .search_section {
        display: flex;
        align-items: center;
        position: relative;
        margin-top: 20px; /* Added some space between search and nav items */
    }



    /* Responsive styles for mobile */
    @media (max-width: 768px) {
        .nav_container {
            flex-direction: column;
            align-items: center;
            padding: 5px;
        }

        .logo_section {
            margin-bottom: 8px;
        }

        .nav_item {
            margin: 10px 0;
        }

        .search_section {
            width: 100%;
            margin-top: 15px;
        }

        .search_field {
            width: 180px;
        }
    }
</style>



</head>
<body>

    <div id="header_wrapper">
        <header>
            <!-- Utility Navigation: 회원가입, 로그인, 로그아웃, 마이페이지 등 -->
            
            <!-- Main Navigation -->
            <div class="nav_container">
                <!-- Logo Section -->
                <a href="index.php" class="logo_link">
                    <div class="logo_section">
                        <img class="logo_icon" src="img/index/gym_logo.png" alt="Logo">
                        <span class="logo_text">마음가GYM</span>
                    </div>
                </a>

                <!-- Navigation Links -->
                <a href="index.php">
                    <div class="nav_item">
                        <img class="nav_icon" src="img/index/home.png" alt="Home">
                        <span class="nav_title">HOME</span>
                    </div>
                </a>

                <a href="recommend_home.php">
                    <div class="nav_item">
                        <img class="nav_icon" src="img/index/record.png" alt="Routine">
                        <span class="nav_title">ROUTINE</span>
                    </div>
                </a>

                <a href="social_qna_home.php">
                    <div class="nav_item">
                        <img class="nav_icon" src="img/index/social.png" alt="Social">
                        <span class="nav_title">SOCIAL</span>
                    </div>
                </a>

                <a href="account_home.php">
                    <div class="nav_item">
                        <img class="nav_icon" src="img/index/account.png" alt="Account">
                        <span class="nav_title">ACCOUNT</span>
                    </div>
                </a>

                <!-- Login Navigation (appears only when not logged in) -->
                <a href="login.php">
                    <div class="nav_item">
                        <img class="nav_icon" src="img/index/account.png" alt="Login">
                        <span class="nav_title">LOGIN</span>
                    </div>
                </a>

            </div>
        </header>
    </div>

</body>
</html>
