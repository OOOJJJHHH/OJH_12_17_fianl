<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>마음가GYM</title>
</head>

<body style="display: flex; flex-direction: column; height: 100%; margin: 0;">

    <!-- Main content here -->
    <div style="flex: 1;">
        <!-- Your main content goes here -->
    </div>
    
    <footer style="background-color: black; height: 60px; width: 100%; font-size: 16px; color: white; padding: 10px; display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 100;">
        <div style="width: 50%; display: flex; justify-content: space-between;">
            <div>상호 : 마음가GYM</div>
            <div><address>사업장 소재지 : 경기도 성남시 중원구 광명로 377 남관 111호</address></div>
        </div>
        <div style="height: 10px;"></div> <!-- Reduced gap for a more compact look -->
        <div style="width: 50%; display: flex; justify-content: space-between;">
            <div>대표 이사 : 오준희</div>
            <div>대표 전화 : 010-7765-9422</div>
        </div>
        <div style="text-align: center; margin-top: 5px;">
            <ul style="list-style-type: none; padding: 0; margin: 0;">
                <li>HEARTGYM(c) 2024 GYM ALL RIGHT RESERVED.</li>
            </ul>
        </div>
    </footer>

</body>

</html>
