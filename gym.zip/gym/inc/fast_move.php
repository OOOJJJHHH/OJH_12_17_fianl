<div class="fast_move_wrapper">
        <div class="good_company_link">
            <span class="good_company_title"> 착한 <br /> 기업 </span>
        </div>
        <div class="go_top_screen"  onClick="javascript:window.scrollTo(0,0)">
            <i class="fa-solid fa-caret-up fa-2x"></i>
        </div>
        <div class="go_bottom_screen" onClick="javascript:window.scrollTo(0,document.body.scrollHeight)" >
            <i class="fa-solid fa-caret-down fa-2x"></i>
        </div>
        <div class="kakao_counseling_link">
            <img src="https://play-lh.googleusercontent.com/Ob9Ys8yKMeyKzZvl3cB9JNSTui1lJwjSKD60IVYnlvU2DsahysGENJE-txiRIW9_72Vd"
                alt="">
        </div>
</div>

<script src="https://kit.fontawesome.com/55083c7425.js" crossorigin="anonymous"></script>
