<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <title>마음가GYM</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .sidebar {
            position: fixed;
            left: 15%;
            top: 30%;
            transform: translateY(-50%);
            width: 150px;
            background-color: thistle;
            padding: 20px 10px;
            color: white;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .sidebar li {
            margin: 10px;
            font-size: 1.2em;
        }

        .sidebar a {
            text-decoration: none;
            color: white;
            padding: 5px 10px;
            transition: all 0.3s ease;
        }

        .sidebar a:hover {
            color: #ddd;
            cursor: pointer;
        }

        /* Center Image Styles (Adjusted Slightly Upward) */
        .center-image {
            position: absolute;
            top: 45%; /* Adjusted slightly upward from 50% */
            left: 50%;
            transform: translate(-50%, -50%);
        }
    </style>
</head>
<body>
    
    <?php require_once("inc/header.php"); ?>

    <div class="sidebar">
        <ul>
            <li><a href="account_home.php">홈</a></li>
            <li><a href="account_faq.php">faq</a></li>
            <li><a href="account_dm.php" style="display: inline-block; border-bottom: 4px solid Red; padding-bottom: 5px;">dm</a></li>
        </ul>
    </div>
    
    <!-- Center Image -->
    <div class="center-image">
        <img src="img/index/faq_home.png">
    </div>

    <?php require_once("inc/footer.php"); ?>
</body>
</html>
