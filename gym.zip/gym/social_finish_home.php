<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="/favicon.ico" type="image/x-icon">
    <title>마음가GYM</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #ffffff; /* 전체 배경을 흰색으로 설정 */
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            flex-direction: column; /* 추가: 세로 방향으로 정렬 */
        }
        .card-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3열 */
            gap: 20px;
            width: 80%; /* 전체 너비의 80% */
            max-width: 1200px;
            margin: 0 auto;
            margin-top: 20px; /* 헤더 아래 여백 */
        }
        .card {
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 200px;
            cursor: pointer;
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: scale(1.05); /* 카드 확대 효과 */
        }
        .card-content {
            padding: 20px;
            text-align: center;
            flex-grow: 1;
        }
        .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            border-top: 1px solid #ddd;
        }
        .card-footer span {
            font-size: 14px;
            color: #555;
        }
        .card-footer .icons {
            display: flex;
            gap: 10px;
        }
        .card-footer .icon {
            font-size: 16px;
            cursor: pointer;
            color: #ccc; /* 기본 빈 하트 색상 */
            transition: color 0.3s ease;
        }
        .card-footer .icon.filled {
            color: #e74c3c; /* 채워진 하트 색상 */
        }
    </style>
</head>
<body>

    <?php require_once("inc/header.php"); ?>
    <?php require_once("social_menu.php"); ?>
    <div class="card-container">
        <!-- 카드 1 -->
        <div class="card" onclick="openPopup('post_view.php?id=1')">
            <div class="card-content">글 제목 1</div>
            <div class="card-footer">
                <span>글 제목 1</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=1')">💬</span>
                </div>
            </div>
        </div>
        <!-- 카드 2 -->
        <div class="card" onclick="openPopup('post_view.php?id=2')">
            <div class="card-content">글 제목 2</div>
            <div class="card-footer">
                <span>글 제목 2</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=2')">💬</span>
                </div>
            </div>
        </div>
        <!-- 카드 3 -->
        <div class="card" onclick="openPopup('post_view.php?id=3')">
            <div class="card-content">글 제목 3</div>
            <div class="card-footer">
                <span>글 제목 3</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=3')">💬</span>
                </div>
            </div>
        </div>
        <!-- 카드 4 -->
        <div class="card" onclick="openPopup('post_view.php?id=4')">
            <div class="card-content">글 제목 4</div>
            <div class="card-footer">
                <span>글 제목 4</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=4')">💬</span>
                </div>
            </div>
        </div>
        <!-- 카드 5 -->
        <div class="card" onclick="openPopup('post_view.php?id=5')">
            <div class="card-content">글 제목 5</div>
            <div class="card-footer">
                <span>글 제목 5</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=5')">💬</span>
                </div>
            </div>
        </div>
        <!-- 카드 6 -->
        <div class="card" onclick="openPopup('post_view.php?id=6')">
            <div class="card-content">글 제목 6</div>
            <div class="card-footer">
                <span>글 제목 6</span>
                <div class="icons">
                    <span class="icon heart-icon" onclick="toggleHeart(event)">♡</span>
                    <span class="icon" onclick="openPopup('post_view.php?id=6')">💬</span>
                </div>
            </div>
        </div>
    </div>

    <?php require_once("inc/footer.php"); ?>

    <script>
        // 하트 토글 기능
        function toggleHeart(event) {
            event.stopPropagation(); // 부모 요소의 클릭 이벤트가 실행되지 않도록 중단
            const heart = event.target;

            if (heart.textContent === "♡") {
                heart.textContent = "❤️"; // 채워진 하트로 변경
                heart.classList.add("filled");
            } else {
                heart.textContent = "♡"; // 빈 하트로 변경
                heart.classList.remove("filled");
            }
        }

        // 팝업 열기
        function openPopup(url) {
            window.open(url, 'popupWindow', 'width=600,height=400,scrollbars=yes');
        }
    </script>

</body>
</html>
